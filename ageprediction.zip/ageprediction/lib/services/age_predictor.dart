import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class TFLiteService {
  static final TFLiteService _instance = TFLiteService._internal();
  factory TFLiteService() => _instance;
  TFLiteService._internal();

  Interpreter? _interpreter;

  bool _loaded = false;

  Future<void> loadModel() async {
    if (_loaded) return;
    try {
      _interpreter = await Interpreter.fromAsset('assets/age_model.tflite');
      _loaded = true;
    } catch (e) {
      print("Error loading model: $e");
    }
  }

  Future<double> predictAge(File imageFile) async {
    if (!_loaded) throw Exception("Model not loaded!");

    final rawImage = img.decodeImage(imageFile.readAsBytesSync());
    if (rawImage == null) throw Exception("Invalid image");

    final resized = img.copyResize(rawImage, width: 160, height: 160);

    var input = List.generate(
      1,
      (_) => List.generate(
        160,
        (_) => List.generate(160, (_) => List.filled(3, 0.0)),
      ),
    );

    for (int y = 0; y < 160; y++) {
      for (int x = 0; x < 160; x++) {
        final pixel = resized.getPixel(x, y);
        input[0][y][x][0] = img.getRed(pixel) / 255.0;
        input[0][y][x][1] = img.getGreen(pixel) / 255.0;
        input[0][y][x][2] = img.getBlue(pixel) / 255.0;
      }
    }

    /// Output format model: [[predicted_age]]
    var output = List.generate(1, (_) => List.filled(1, 0.0));

    _interpreter!.run(input, output);
    return output[0][0]; // <- Ambil nilai umur
  }
}
