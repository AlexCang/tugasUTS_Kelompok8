import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class AgePredictionResult {
  final double age;
  final String range;
  final double confidence;

  AgePredictionResult({
    required this.age,
    required this.range,
    required this.confidence,
  });
}

class TFLiteService {
  static final TFLiteService _instance = TFLiteService._internal();
  factory TFLiteService() => _instance;
  TFLiteService._internal();

  Interpreter? _interpreter;
  bool _loaded = false;

  // Tambahkan getter public untuk interpreter
  Interpreter? get interpreter => _interpreter;

  Future<void> loadModel() async {
    if (_loaded) return;
    _interpreter = await Interpreter.fromAsset('assets/age_model.tflite');
    _loaded = true;
  }

  Future<AgePredictionResult> predictAge(File imageFile) async {
    if (!_loaded) throw Exception("Model not loaded!");

    final rawImage = img.decodeImage(imageFile.readAsBytesSync());
    if (rawImage == null) throw Exception("Invalid image");

    final resized = img.copyResize(rawImage, width: 160, height: 160);

    var input = List.generate(
      1,
      (_) => List.generate(
        160,
        (_) => List.generate(160, (_) => List.filled(3, 0.0)),
      ),
    );

    for (int y = 0; y < 160; y++) {
      for (int x = 0; x < 160; x++) {
        final pixel = resized.getPixel(x, y);
        input[0][y][x][0] = img.getRed(pixel) / 255.0;
        input[0][y][x][1] = img.getGreen(pixel) / 255.0;
        input[0][y][x][2] = img.getBlue(pixel) / 255.0;
      }
    }

    var output = List.generate(1, (_) => List.filled(1, 0.0));
    _interpreter!.run(input, output);

    final double age = output[0][0];

    final int minAge = (age - 3).clamp(0, 120).floor();
    final int maxAge = (age + 3).clamp(0, 120).ceil();

    double confidence;
    if (age < 10 || age > 70) {
      confidence = 0.70;
    } else if (age < 20 || age > 60) {
      confidence = 0.80;
    } else {
      confidence = 0.92;
    }

    return AgePredictionResult(
      age: age,
      range: "$minAge - $maxAge years",
      confidence: confidence,
    );
  }

  // Tambahkan method untuk prediksi dari input array langsung
  AgePredictionResult predictFromInput(List<List<List<List<double>>>> input) {
    if (_interpreter == null) {
      throw Exception("Model not loaded!");
    }

    var output = List.generate(1, (_) => List.filled(1, 0.0));
    _interpreter!.run(input, output);

    final double age = output[0][0];
    final int minAge = (age - 3).clamp(0, 120).floor();
    final int maxAge = (age + 3).clamp(0, 120).ceil();

    double confidence;
    if (age < 10 || age > 70) {
      confidence = 0.70;
    } else if (age < 20 || age > 60) {
      confidence = 0.80;
    } else {
      confidence = 0.92;
    }

    return AgePredictionResult(
      age: age,
      range: "$minAge - $maxAge years",
      confidence: confidence,
    );
  }
}
