import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<String> uploadImage(File file) async {
    final fileName = "blogimages/${DateTime.now().millisecondsSinceEpoch}.jpg";
    final ref = _storage.ref().child(fileName);
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }

  Future<String> savePrediction(File file, double age) async {
    final imageUrl = await uploadImage(file);

    final docRef = await _firestore.collection("age_predictions").add({
      "imageUrl": imageUrl,
      "age": age,
      "createdAt": FieldValue.serverTimestamp(), // ✅ FIX HERE
    });

    return docRef.id;
  }

  Future<void> deletePredictionById(String docId) async {
    final doc = await _firestore.collection("age_predictions").doc(docId).get();
    if (!doc.exists) return;

    final data = doc.data();
    if (data != null && data['imageUrl'] != null) {
      final ref = _storage.refFromURL(data['imageUrl']);
      await ref.delete();
    }
    await _firestore.collection("age_predictions").doc(docId).delete();
  }
}
