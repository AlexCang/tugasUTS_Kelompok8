import 'dart:io';
import 'package:flutter/material.dart';
import 'package:ageprediction/services/firebase_service.dart';

class ResultScreen extends StatefulWidget {
  final double age;
  final File file;

  const ResultScreen({
    super.key,
    required this.age,
    required this.file,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final FirebaseService _firebaseService = FirebaseService();
  bool _saving = false;
  bool _savedSuccess = false;

  Future<void> _saveToFirebase() async {
    setState(() => _saving = true);
    try {
      await _firebaseService.savePrediction(widget.file, widget.age);
      setState(() {
        _saving = false;
        _savedSuccess = true;
      });
    } catch (e) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Error: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A0E21),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text("AI Result", style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        // ✅ BENAR-BENAR CENTER
        child: SingleChildScrollView(
          // ✅ Biar tetap center meski content tinggi
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: Colors.blueAccent.shade700,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueAccent.withOpacity(.5),
                      blurRadius: 15,
                      spreadRadius: 3,
                    )
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.file(
                    widget.file,
                    width: 260,
                    height: 260,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 28),
              Text(
                "AI Estimated Age",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.blueAccent.shade100,
                  letterSpacing: 1.2,
                ),
              ),
              Text(
                "${widget.age.toStringAsFixed(1)} years",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      blurRadius: 12,
                      color: Colors.blueAccent,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              if (_saving)
                const CircularProgressIndicator(color: Colors.blueAccent)
              else if (_savedSuccess)
                const Icon(Icons.check_circle,
                    size: 50, color: Colors.greenAccent)
              else
                _buildNeonButton(
                  text: "Save Result",
                  onTap: _saveToFirebase,
                ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, "/history"),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.blueAccent, width: 1.8),
                  ),
                  child: const Text(
                    "View History",
                    style: TextStyle(
                      color: Colors.blueAccent,
                      fontSize: 16,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeonButton({required String text, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 18),
        decoration: BoxDecoration(
          color: Colors.blueAccent.shade700,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.blueAccent.withOpacity(.6),
              blurRadius: 20,
              spreadRadius: 2,
            )
          ],
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 17,
            letterSpacing: 1,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
