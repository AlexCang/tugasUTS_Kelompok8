import 'dart:io';
import 'package:flutter/material.dart';
import 'package:ageprediction/services/firebase_service.dart';

class ResultScreen extends StatefulWidget {
  final double age;
  final String range;
  final double confidence;
  final File file;

  const ResultScreen({
    super.key,
    required this.age,
    required this.range,
    required this.confidence,
    required this.file,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final FirebaseService _firebaseService = FirebaseService();
  bool _saving = false;
  bool _savedSuccess = false;

  Future<void> _saveToFirebase() async {
    setState(() => _saving = true);
    await _firebaseService.savePrediction(
      widget.file,
      widget.age,
      widget.range,
      widget.confidence,
    );
    setState(() {
      _saving = false;
      _savedSuccess = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A0E21),
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("AI Result", style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Image.file(widget.file, width: 260, height: 260),
              const SizedBox(height: 20),
              Text(
                "${widget.age.toStringAsFixed(1)} years",
                style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              const SizedBox(height: 10),
              Text(
                "Age Range: ${widget.range}",
                style: const TextStyle(color: Colors.white),
              ),
              Text(
                "Confidence: ${(widget.confidence * 100).toStringAsFixed(0)}%",
                style: const TextStyle(color: Colors.greenAccent),
              ),
              const SizedBox(height: 30),
              if (_saving)
                const CircularProgressIndicator()
              else if (_savedSuccess)
                const Icon(Icons.check_circle,
                    size: 50, color: Colors.greenAccent)
              else
                ElevatedButton(
                  onPressed: _saveToFirebase,
                  child: const Text("Save Result"),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
