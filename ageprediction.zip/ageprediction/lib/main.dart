import 'package:ageprediction/detail_screen.dart';
import 'package:ageprediction/history_screen.dart';
import 'package:ageprediction/home_screen.dart';
import 'package:ageprediction/result_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // WAJIB, agar Firebase aktif
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Age Prediction App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/detail': (context) => const DetailScreen(),
        '/history': (context) => HistoryScreen(),
        '/result': (context) => _buildResultFromArgs(context), // Tambahkan ini
      },
      home: const HomeScreen(),
    );
  }
}

Widget _buildResultFromArgs(BuildContext context) {
  final args =
      ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
  return ResultScreen(
    age: args['age'],
    range: args['range'],
    confidence: args['confidence'],
    file: args['file'],
  );
}
