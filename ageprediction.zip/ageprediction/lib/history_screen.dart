import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:ageprediction/services/firebase_service.dart';

class HistoryScreen extends StatelessWidget {
  HistoryScreen({super.key});

  final FirebaseService _firebaseService = FirebaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A0E21),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text("History", style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("age_predictions")
            .orderBy("createdAt", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                "No history yet.",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.blueAccent.shade100,
                ),
              ),
            );
          }

          final docs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final id = doc.id;
              final data = doc.data() as Map<String, dynamic>;

              final imageUrl = data['imageUrl'];
              final age = data['age'];

              final rawDate = data['createdAt'];
              late DateTime date;
              if (rawDate is Timestamp) {
                date = rawDate.toDate();
              } else if (rawDate is int) {
                date = DateTime.fromMillisecondsSinceEpoch(rawDate);
              } else {
                date = DateTime.now();
              }

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.blueAccent.shade700,
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueAccent.withOpacity(.3),
                      blurRadius: 10,
                      spreadRadius: 1,
                    )
                  ],
                ),
                child: ListTile(
                  onTap: () => Navigator.pushNamed(
                    context,
                    "/detail",
                    arguments: {
                      "imageUrl": imageUrl,
                      "age": age,
                      "createdAt": data['createdAt'],
                      "id": id,
                    },
                  ),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      imageUrl,
                      width: 55,
                      height: 55,
                      fit: BoxFit.cover,
                    ),
                  ),
                  title: Text(
                    "Age: ${age.toStringAsFixed(1)} years",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    "${date.day}/${date.month}/${date.year}  "
                    "${date.hour}:${date.minute.toString().padLeft(2, '0')}",
                    style: TextStyle(
                      color: Colors.blueAccent.shade100,
                    ),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.redAccent),
                    onPressed: () async {
                      await _firebaseService.deletePredictionById(id);
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
