import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ageprediction/services/age_predictor.dart';
import 'package:ageprediction/result_screen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  final TFLiteService _tflite = TFLiteService();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _tflite.loadModel();
  }

  /// ✅ FIX: copy picked image to internal app storage
  Future<File> _copyToAppDir(XFile picked) async {
    final appDir = await getApplicationDocumentsDirectory();
    final fileName =
        "img_${DateTime.now().millisecondsSinceEpoch}${path.extension(picked.path)}";
    final savedImage =
        await File(picked.path).copy(path.join(appDir.path, fileName));
    return savedImage;
  }

  Future<void> _processImage(ImageSource source) async {
    final picked = await _picker.pickImage(source: source);
    if (picked == null) return;

    setState(() => _loading = true);

    // ✅ This is the REAL file we will use (not the temp one)
    final safeFile = await _copyToAppDir(picked);

    final age = await _tflite.predictAge(safeFile);

    setState(() => _loading = false);

    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          age: age,
          file: safeFile, // ✅ now always upload-safe file
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A0E21),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text("AI Age Predictor",
            style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Welcome to Age Prediction",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.blueAccent.shade100,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 40),
              if (_loading)
                const CircularProgressIndicator(color: Colors.blueAccent)
              else
                Column(
                  children: [
                    _buildNeonButton(
                      text: "Take Photo",
                      icon: Icons.camera_alt,
                      onTap: () => _processImage(ImageSource.camera),
                    ),
                    const SizedBox(height: 20),
                    _buildNeonButton(
                      text: "Pick From Gallery",
                      icon: Icons.photo_library,
                      onTap: () => _processImage(ImageSource.gallery),
                    ),
                  ],
                ),
              const SizedBox(height: 40),
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, "/history"),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.blueAccent, width: 1.8),
                  ),
                  child: const Text(
                    "View History",
                    style: TextStyle(
                      color: Colors.blueAccent,
                      fontSize: 16,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeonButton(
      {required String text,
      required IconData icon,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 18),
        decoration: BoxDecoration(
          color: Colors.blueAccent.shade700,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.blueAccent.withOpacity(.6),
              blurRadius: 20,
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                letterSpacing: 1,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
