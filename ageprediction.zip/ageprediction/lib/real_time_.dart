import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:image/image.dart' as img;
import 'package:ageprediction/services/age_predictor.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;

class RealtimePredictionScreen extends StatefulWidget {
  const RealtimePredictionScreen({super.key});

  @override
  State<RealtimePredictionScreen> createState() =>
      _RealtimePredictionScreenState();
}

class _RealtimePredictionScreenState extends State<RealtimePredictionScreen> {
  CameraController? _cameraController;
  final TFLiteService _tflite = TFLiteService();

  bool _isProcessing = false;
  bool _isInitialized = false;
  String _errorMessage = '';

  // Hasil prediksi realtime
  double? _currentAge;
  String? _currentRange;
  double? _currentConfidence;

  int _frameCount = 0;

  @override
  void initState() {
    super.initState();
    _initializeAll();
  }

  Future<void> _initializeAll() async {
    try {
      debugPrint("Loading model...");
      await _tflite.loadModel();
      debugPrint("Model loaded successfully");

      debugPrint("Initializing camera...");
      await _initializeCamera();
      debugPrint("Camera initialized successfully");
    } catch (e) {
      setState(() {
        _errorMessage = 'Initialization error: $e';
      });
      debugPrint("Initialization error: $e");
    }
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() {
          _errorMessage = "No cameras available";
        });
        return;
      }

      // Gunakan kamera depan
      final frontCamera = cameras.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(
        frontCamera,
        ResolutionPreset.low, // PENTING: gunakan low untuk performa lebih baik
        enableAudio: false,
      );

      await _cameraController!.initialize();

      if (!mounted) return;

      setState(() {
        _isInitialized = true;
        _errorMessage = '';
      });

      debugPrint("Starting image stream...");
      // Delay sebentar sebelum mulai stream
      await Future.delayed(const Duration(milliseconds: 500));
      _startImageStream();
    } catch (e) {
      setState(() {
        _errorMessage = "Camera error: $e";
      });
      debugPrint("Error initializing camera: $e");
    }
  }

  void _startImageStream() {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      debugPrint("Camera not ready for streaming");
      return;
    }

    try {
      _cameraController!.startImageStream((CameraImage image) {
        _frameCount++;

        // Proses hanya setiap 90 frame (sekitar 1x per 3 detik) - LEBIH LAMBAT
        if (_frameCount % 90 != 0) {
          return;
        }

        if (!_isProcessing) {
          _isProcessing = true;
          debugPrint("Processing frame ${_frameCount}...");

          _processImageSimplified(image).catchError((e) {
            debugPrint("Process image error: $e");
          }).whenComplete(() {
            _isProcessing = false;
          });
        }
      });
      debugPrint("Image stream started");
    } catch (e) {
      debugPrint("Start image stream error: $e");
      setState(() {
        _errorMessage = "Stream error: $e";
      });
    }
  }

  Future<void> _processImageSimplified(CameraImage cameraImage) async {
    try {
      debugPrint("=== Starting image processing ===");
      debugPrint("Image size: ${cameraImage.width}x${cameraImage.height}");
      debugPrint("Format: ${cameraImage.format.group}");

      // Konversi YUV420 ke RGB (Full conversion untuk akurasi lebih baik)
      final int width = cameraImage.width;
      final int height = cameraImage.height;

      final yPlane = cameraImage.planes[0];
      final uPlane = cameraImage.planes[1];
      final vPlane = cameraImage.planes[2];

      debugPrint("Converting YUV to RGB...");
      final img.Image fullImage = img.Image(width, height);

      for (int h = 0; h < height; h++) {
        for (int w = 0; w < width; w++) {
          final int uvIndex = (h ~/ 2) * uPlane.bytesPerRow +
              (w ~/ 2) * (uPlane.bytesPerPixel ?? 1);
          final int index = h * width + w;

          final int y = yPlane.bytes[index];
          final int u = uPlane.bytes[uvIndex];
          final int v = vPlane.bytes[uvIndex];

          // YUV to RGB conversion
          int r = (y + 1.402 * (v - 128)).round().clamp(0, 255);
          int g = (y - 0.344136 * (u - 128) - 0.714136 * (v - 128))
              .round()
              .clamp(0, 255);
          int b = (y + 1.772 * (u - 128)).round().clamp(0, 255);

          // API versi 3.x.x
          final color = img.getColor(r, g, b);
          fullImage.setPixel(w, h, color);
        }
      }

      debugPrint("Resizing to 160x160...");
      final resized = img.copyResize(
        fullImage,
        width: 160,
        height: 160,
        interpolation: img.Interpolation.linear,
      );

      debugPrint("Preparing input tensor...");
      var input = List.generate(
        1,
        (_) => List.generate(
          160,
          (_) => List.generate(160, (_) => List.filled(3, 0.0)),
        ),
      );

      for (int y = 0; y < 160; y++) {
        for (int x = 0; x < 160; x++) {
          final pixel = resized.getPixel(x, y);
          // API versi 3.x.x
          input[0][y][x][0] = img.getRed(pixel) / 255.0;
          input[0][y][x][1] = img.getGreen(pixel) / 255.0;
          input[0][y][x][2] = img.getBlue(pixel) / 255.0;
        }
      }

      debugPrint("Running TFLite prediction...");
      final result = _tflite.predictFromInput(input);

      debugPrint(
          "✅ SUCCESS - Age: ${result.age.toStringAsFixed(1)}, Range: ${result.range}, Confidence: ${result.confidence}");

      if (mounted) {
        setState(() {
          _currentAge = result.age;
          _currentRange = result.range;
          _currentConfidence = result.confidence;
        });
        debugPrint("UI updated with prediction results");
      }
    } catch (e, stackTrace) {
      debugPrint("❌ ERROR processing image: $e");
      debugPrint("Stack trace: $stackTrace");

      // Tampilkan error di UI juga
      if (mounted) {
        setState(() {
          _errorMessage = "Processing error: $e";
        });
      }
    }
  }

  Future<void> _captureAndSave() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return;
    }

    if (_currentAge == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please wait for detection...'),
            duration: Duration(seconds: 1),
          ),
        );
      }
      return;
    }

    try {
      debugPrint("Stopping image stream for capture...");
      // Stop image stream sementara
      await _cameraController!.stopImageStream();

      // Tunggu sebentar
      await Future.delayed(const Duration(milliseconds: 200));

      debugPrint("Taking picture...");
      // Ambil foto
      final XFile photo = await _cameraController!.takePicture();

      debugPrint("Saving picture...");
      // Copy ke app directory
      final appDir = await getApplicationDocumentsDirectory();
      final fileName =
          "img_${DateTime.now().millisecondsSinceEpoch}${path.extension(photo.path)}";
      final savedFile =
          await File(photo.path).copy(path.join(appDir.path, fileName));

      debugPrint("Navigating to result screen...");
      // Navigate ke result screen dengan data yang sudah ada
      if (!mounted) return;

      Navigator.pushNamed(
        context,
        "/result",
        arguments: {
          "file": savedFile,
          "age": _currentAge!,
          "range": _currentRange!,
          "confidence": _currentConfidence!,
        },
      );

      // Restart image stream
      debugPrint("Restarting image stream...");
      _frameCount = 0; // Reset frame count
      _startImageStream();
    } catch (e) {
      debugPrint("Error capturing photo: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Capture error: $e')),
        );
      }

      // Restart image stream jika error
      try {
        _frameCount = 0;
        _startImageStream();
      } catch (e) {
        debugPrint("Error restarting stream: $e");
      }
    }
  }

  @override
  void dispose() {
    debugPrint("Disposing camera controller...");
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A0E21),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Real-time Detection",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _errorMessage.isNotEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      color: Colors.redAccent,
                      size: 60,
                    ),
                    const SizedBox(height: 20),
                    Text(
                      _errorMessage,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _errorMessage = '';
                          _frameCount = 0;
                        });
                        _initializeAll();
                      },
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            )
          : !_isInitialized
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Colors.blueAccent),
                      SizedBox(height: 20),
                      Text(
                        'Initializing camera...',
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                )
              : Stack(
                  children: [
                    // Camera Preview
                    Positioned.fill(
                      child: CameraPreview(_cameraController!),
                    ),

                    // Overlay dengan informasi prediksi
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 30,
                        ),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withOpacity(0.85),
                              Colors.black.withOpacity(0.3),
                              Colors.transparent,
                            ],
                          ),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_currentAge != null) ...[
                              Text(
                                "${_currentAge!.toStringAsFixed(1)} years",
                                style: const TextStyle(
                                  fontSize: 48,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  shadows: [
                                    Shadow(
                                      blurRadius: 15.0,
                                      color: Colors.black,
                                      offset: Offset(2.0, 2.0),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                "Range: $_currentRange",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.blueAccent.shade100,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                "Confidence: ${(_currentConfidence! * 100).toStringAsFixed(0)}%",
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.greenAccent,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 25),
                            ] else ...[
                              const Text(
                                "Detecting face...",
                                style: TextStyle(
                                  fontSize: 22,
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 15),
                              const SizedBox(
                                width: 30,
                                height: 30,
                                child: CircularProgressIndicator(
                                  strokeWidth: 3,
                                  color: Colors.blueAccent,
                                ),
                              ),
                              const SizedBox(height: 25),
                            ],

                            // Tombol Capture
                            GestureDetector(
                              onTap: _captureAndSave,
                              child: Container(
                                width: 75,
                                height: 75,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 5,
                                  ),
                                  color: _currentAge != null
                                      ? Colors.blueAccent.shade700
                                      : Colors.grey.shade700,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _currentAge != null
                                          ? Colors.blueAccent.withOpacity(0.7)
                                          : Colors.grey.withOpacity(0.3),
                                      blurRadius: 25,
                                      spreadRadius: 3,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.camera_alt,
                                  color: Colors.white,
                                  size: 35,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Frame counter (debug)
                    if (_isProcessing)
                      Positioned(
                        top: 15,
                        right: 15,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.blueAccent.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(width: 8),
                              Text(
                                "Analyzing",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}
