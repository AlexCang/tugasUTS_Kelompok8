package com.example.ageprediction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
